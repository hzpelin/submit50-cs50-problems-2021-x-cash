#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //prompt for height
        int height;
        do
    {
        height = get_int("height: ");
    }
         while (height<1 || height>8);
    // loop body
        for (int i=0 ; i<height; i++)
    {
            for (int j=0 ; j<height; j++)
            {
                    if(i + j >= height-1)
                printf("#");
                    else
                printf(" ");
            }
        printf("\n");

     }

}